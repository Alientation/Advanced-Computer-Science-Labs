public class NewAvatar extends Entity {
	
	public NewAvatar(int x, int y, int hp, int damage, String name, String renderImage, Stats timer, Entity.Direction direction) {
		super(x, y, hp, damage, name, renderImage, timer, direction);
	}
}