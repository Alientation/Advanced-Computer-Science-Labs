class NewMonster extends Entity {
	public NewMonster(int x, int y, int hp, int damage, String name, String renderImage, Stats timer, Direction direction) {
		super(x,y,hp,damage,name,renderImage,timer,direction);
	}
}